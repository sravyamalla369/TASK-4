document.getElementById('filter').addEventListener('change', filterProducts);

function filterProducts() {
  const filterValue = document.getElementById('filter').value;
  const productList = document.getElementById('productList');
  const products = productList.getElementsByTagName('li');
  Array.from(products).forEach(product => {
    const category = product.getAttribute('data-category');
    product.style.display = category === filterValue || filterValue === '' ? 'block' : 'none';
  });
}

function sortProducts() {
  const productList = document.getElementById('productList');
  const products = Array.from(productList.getElementsByTagName('li'));
  products.sort((a, b) => {
    return parseFloat(b.getAttribute('data-rating')) - parseFloat(a.getAttribute('data-rating'));
  });
  products.forEach(product => {
    productList.appendChild(product);
  });
}
