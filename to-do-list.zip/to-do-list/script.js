const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// Load tasks on page load
window.addEventListener("DOMContentLoaded", loadTasks);

addBtn.addEventListener("click", addTask);

function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText === "") return;

  const task = {
    id: Date.now(),
    text: taskText,
    completed: false
  };

  const tasks = getTasksFromStorage();
  tasks.push(task);
  saveTasksToStorage(tasks);
  renderTask(task);

  taskInput.value = "";
}

function renderTask(task) {
  const li = document.createElement("li");
  li.dataset.id = task.id;
  li.className = task.completed ? "completed" : "";

  li.innerHTML = `
    <span>${task.text}</span>
    <div>
      <button class="delete">Delete</button>
    </div>
  `;

  li.addEventListener("click", function (e) {
    if (e.target.classList.contains("delete")) {
      deleteTask(task.id);
    } else {
      toggleTask(task.id);
    }
  });

  taskList.appendChild(li);
}

function loadTasks() {
  const tasks = getTasksFromStorage();
  tasks.forEach(renderTask);
}

function deleteTask(id) {
  let tasks = getTasksFromStorage();
  tasks = tasks.filter(task => task.id !== id);
  saveTasksToStorage(tasks);
  document.querySelector(`li[data-id="${id}"]`).remove();
}

function toggleTask(id) {
  let tasks = getTasksFromStorage();
  tasks = tasks.map(task => {
    if (task.id === id) task.completed = !task.completed;
    return task;
  });
  saveTasksToStorage(tasks);
  taskList.innerHTML = "";
  tasks.forEach(renderTask);
}

function getTasksFromStorage() {
  return JSON.parse(localStorage.getItem("tasks")) || [];
}

function saveTasksToStorage(tasks) {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}
